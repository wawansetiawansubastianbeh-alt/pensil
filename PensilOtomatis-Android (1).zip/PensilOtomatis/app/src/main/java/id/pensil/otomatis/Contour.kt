package id.pensil.otomatis
import android.graphics.Bitmap
import android.graphics.PointF

object Contour {
    /** Pilih objek: tumbuhkan area dari titik sentuh berdasarkan kemiripan warna. */
    fun region(bmp: Bitmap, sx: Int, sy: Int, tol: Int): BooleanArray {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        var r = 0; var g = 0; var b = 0; var n = 0
        for (dy in -2..2) for (dx in -2..2) {
            val x = sx + dx; val y = sy + dy
            if (x in 0 until w && y in 0 until h) { val c = px[y * w + x]; r += c shr 16 and 255; g += c shr 8 and 255; b += c and 255; n++ }
        }
        r /= n; g /= n; b /= n
        val t2 = tol * tol * 3
        val mask = BooleanArray(w * h); val q = IntArray(w * h); var head = 0; var tail = 0
        fun ok(i: Int): Boolean {
            val c = px[i]; val dr = (c shr 16 and 255) - r; val dg = (c shr 8 and 255) - g; val db = (c and 255) - b
            return dr * dr + dg * dg + db * db <= t2
        }
        val s = sy * w + sx; mask[s] = true; q[tail++] = s
        while (head < tail) {
            val i = q[head++]; val x = i % w; val y = i / w
            if (x > 0 && !mask[i - 1] && ok(i - 1)) { mask[i - 1] = true; q[tail++] = i - 1 }
            if (x < w - 1 && !mask[i + 1] && ok(i + 1)) { mask[i + 1] = true; q[tail++] = i + 1 }
            if (y > 0 && !mask[i - w] && ok(i - w)) { mask[i - w] = true; q[tail++] = i - w }
            if (y < h - 1 && !mask[i + w] && ok(i + w)) { mask[i + w] = true; q[tail++] = i + w }
        }
        // haluskan noise (mayoritas 3x3)
        val out = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            var c = 0
            for (dy in -1..1) for (dx in -1..1) if (mask[(y + dy) * w + x + dx]) c++
            out[y * w + x] = c >= 5
        }
        return out
    }

    /** Ambil garis tepi objek sebagai jalur-jalur menyambung untuk satu pensil. */
    fun trace(mask: BooleanArray, w: Int, h: Int): List<List<PointF>> {
        fun m(x: Int, y: Int) = x in 0 until w && y in 0 until h && mask[y * w + x]
        val edge = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w)
            if (mask[y * w + x] && !(m(x - 1, y) && m(x + 1, y) && m(x, y - 1) && m(x, y + 1))) edge[y * w + x] = true
        val vis = BooleanArray(w * h)
        val dx = intArrayOf(1, 0, -1, 0, 1, -1, -1, 1); val dy = intArrayOf(0, 1, 0, -1, 1, 1, -1, -1)
        val out = ArrayList<List<PointF>>()
        for (i in edge.indices) {
            if (!edge[i] || vis[i]) continue
            val chain = ArrayList<PointF>(); var cx = i % w; var cy = i / w
            vis[i] = true; chain.add(PointF(cx.toFloat(), cy.toFloat()))
            while (true) {
                var found = false
                for (k in 0..7) {
                    val nx = cx + dx[k]; val ny = cy + dy[k]
                    if (nx in 0 until w && ny in 0 until h && edge[ny * w + nx] && !vis[ny * w + nx]) {
                        vis[ny * w + nx] = true; cx = nx; cy = ny; chain.add(PointF(nx.toFloat(), ny.toFloat())); found = true; break
                    }
                }
                if (!found) break
            }
            if (chain.size >= 25) {
                val a = chain.first(); val z = chain.last()
                if (Math.abs(a.x - z.x) <= 2 && Math.abs(a.y - z.y) <= 2) chain.add(PointF(a.x, a.y))
                out.add(smooth(chain))
            }
        }
        return out.sortedByDescending { it.size }.take(10)
    }

    private fun smooth(p: List<PointF>): List<PointF> {
        val o = ArrayList<PointF>()
        var i = 0
        while (i < p.size) {
            var sx = 0f; var sy = 0f; var n = 0
            for (k in -2..2) { val q = p[(i + k).coerceIn(0, p.size - 1)]; sx += q.x; sy += q.y; n++ }
            o.add(PointF(sx / n, sy / n)); i += 2
        }
        if (o.last() != p.last()) o.add(p.last())
        return o
    }
}
