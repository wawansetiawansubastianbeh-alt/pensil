package id.pensil.otomatis
import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var iv: ImageView
    private lateinit var status: TextView
    private var bmp: Bitmap? = null
    private var seed: IntArray? = null
    private var tol = 30

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }.also { root.addView(it) }
        root.addView(TextView(this).apply {
            text = "Pensil Otomatis\n1) Aktifkan layanan Aksesibilitas  2) Pilih foto, sentuh objek yang mau digaris tepinya  3) Tampilkan panel, buka SketchBook, pilih pensil, tekan Area lalu ▶"
        })
        btn("1. Aktifkan layanan Aksesibilitas") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Pilih foto") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1) }
        iv = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_UP) tap(e.x, e.y); true }
        }
        root.addView(iv)
        status = TextView(this).apply { text = "Belum ada foto" }; root.addView(status)
        slider(root, "Toleransi warna objek", 75, 25) { tol = it + 5; recompute() }
        slider(root, "Lambat ↔ cepat (ms/px: 1–15)", 14, 3) { Shared.msPerPx = (it + 1).toFloat() }
        btn("3. Tampilkan panel pensil") {
            val s = DrawService.inst
            if (s == null) Toast.makeText(this, "Aktifkan layanan Aksesibilitas dulu", Toast.LENGTH_LONG).show()
            else { s.showPanel(); moveTaskToBack(true) }
        }
        setContentView(root)
    }

    private fun slider(root: LinearLayout, label: String, max: Int, init: Int, on: (Int) -> Unit) {
        root.addView(TextView(this).apply { text = label })
        root.addView(SeekBar(this).apply {
            this.max = max; progress = init
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { on(progress) }
            })
        })
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1; while (maxOf(o.outWidth, o.outHeight) / ss > 960) ss *= 2
        val raw = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss }) } ?: return
        val k = 480f / maxOf(raw.width, raw.height)
        bmp = if (k < 1f) Bitmap.createScaledBitmap(raw, (raw.width * k).toInt(), (raw.height * k).toInt(), true) else raw
        seed = null; Shared.paths = emptyList(); iv.setImageBitmap(bmp); status.text = "Sentuh objek pada foto"
    }

    private fun tap(x: Float, y: Float) {
        val b = bmp ?: return
        val inv = Matrix(); iv.imageMatrix.invert(inv)
        val p = floatArrayOf(x, y); inv.mapPoints(p)
        val bx = p[0].toInt(); val by = p[1].toInt()
        if (bx !in 0 until b.width || by !in 0 until b.height) return
        seed = intArrayOf(bx, by); recompute()
    }

    private fun recompute() {
        val b = bmp ?: return; val s = seed ?: return
        val paths = Contour.trace(Contour.region(b, s[0], s[1], tol), b.width, b.height)
        Shared.paths = paths; Shared.bw = b.width; Shared.bh = b.height
        val pv = b.copy(Bitmap.Config.ARGB_8888, true); val c = Canvas(pv)
        val pa = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 2f }
        for (l in paths) { val pt = Path(); l.forEachIndexed { i, q -> if (i == 0) pt.moveTo(q.x, q.y) else pt.lineTo(q.x, q.y) }; c.drawPath(pt, pa) }
        iv.setImageBitmap(pv)
        status.text = if (paths.isEmpty()) "Garis tepi tidak ditemukan, naikkan toleransi atau sentuh titik lain" else "${paths.size} jalur garis tepi siap"
    }
}
