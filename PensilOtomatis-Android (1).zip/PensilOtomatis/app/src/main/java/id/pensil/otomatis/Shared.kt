package id.pensil.otomatis
import android.graphics.PointF
import android.graphics.RectF

object Shared {
    @Volatile var paths: List<List<PointF>> = emptyList()
    @Volatile var bw = 0
    @Volatile var bh = 0
    @Volatile var msPerPx = 4f
    @Volatile var rect: RectF? = null
}
