package id.pensil.otomatis
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class DrawService : AccessibilityService() {
    companion object { @Volatile var inst: DrawService? = null }

    private val ui = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var worker: Thread? = null
    @Volatile private var paused = false
    @Volatile private var stopped = false
    private val wm get() = getSystemService(WINDOW_SERVICE) as WindowManager

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; hidePanel(); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun toast(t: String) = ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }

    // ---------- Panel melayang ----------
    fun showPanel() {
        if (panel != null) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xCC222222.toInt()); setPadding(8, 8, 8, 8)
        }
        fun b(t: String, a: () -> Unit) = Button(this).apply {
            text = t; minWidth = 0; minimumWidth = 0; setOnClickListener { a() }
        }.also { box.addView(it) }
        b("Area") { pickArea() }
        b("▶") { start() }
        b("⏸") { paused = !paused; toast(if (paused) "Dijeda" else "Lanjut") }
        b("■") { stopped = true; paused = false }
        b("✕") { stopped = true; hidePanel() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; y = 160 }
        wm.addView(box, lp); panel = box
    }

    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }

    private fun pickArea() {
        val v = object : View(this) {
            var x0 = 0f; var y0 = 0f; var x1 = 0f; var y1 = 0f; var rx0 = 0f; var ry0 = 0f; var rx1 = 0f; var ry1 = 0f
            val fill = Paint().apply { color = 0x5522AAFF }
            val line = Paint().apply { color = 0xFF22AAFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
            override fun onDraw(c: Canvas) { val r = RectF(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1)); c.drawRect(r, fill); c.drawRect(r, line) }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { x0 = e.x; y0 = e.y; x1 = x0; y1 = y0; rx0 = e.rawX; ry0 = e.rawY }
                    MotionEvent.ACTION_MOVE -> { x1 = e.x; y1 = e.y; invalidate() }
                    MotionEvent.ACTION_UP -> {
                        rx1 = e.rawX; ry1 = e.rawY
                        val r = RectF(minOf(rx0, rx1), minOf(ry0, ry1), maxOf(rx0, rx1), maxOf(ry0, ry1))
                        if (r.width() > 80 && r.height() > 80) { Shared.rect = r; toast("Area diset. Tekan ▶") } else toast("Area terlalu kecil")
                        try { wm.removeView(this) } catch (_: Exception) {}
                    }
                }
                return true
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        wm.addView(v, lp)
        toast("Seret persegi di atas kanvas SketchBook")
    }

    // ---------- Menggambar ----------
    private fun start() {
        val r = Shared.rect ?: return toast("Tekan Area dulu")
        if (Shared.paths.isEmpty() || Shared.bw == 0) return toast("Pilih foto & objek di aplikasi dulu")
        if (worker?.isAlive == true) return toast("Masih menggambar")
        val sc = minOf(r.width() / Shared.bw, r.height() / Shared.bh)
        val ox = r.left + (r.width() - Shared.bw * sc) / 2; val oy = r.top + (r.height() - Shared.bh * sc) / 2
        val sp = Shared.paths.map { l -> l.map { PointF(ox + it.x * sc, oy + it.y * sc) } }
        paused = false; stopped = false
        worker = Thread { run(sp); toast(if (stopped) "Dihentikan" else "Selesai") }.also { it.start() }
    }

    private fun run(paths: List<List<PointF>>) {
        for (pts in paths) {
            if (stopped) return
            var prev: GestureDescription.StrokeDescription? = null
            var i = 0
            while (i < pts.size - 1 && !stopped) {
                val end = minOf(i + 24, pts.size - 1)
                val path = Path(); path.moveTo(pts[i].x, pts[i].y); var len = 0f
                for (k in i + 1..end) { path.lineTo(pts[k].x, pts[k].y); len += Math.hypot((pts[k].x - pts[k - 1].x).toDouble(), (pts[k].y - pts[k - 1].y).toDouble()).toFloat() }
                val last = end == pts.size - 1
                val cont = !last && !paused && !stopped
                val dur = maxOf(10L, (len * Shared.msPerPx).toLong())
                val s = prev?.continueStroke(path, 0, dur, cont) ?: GestureDescription.StrokeDescription(path, 0, dur, cont)
                if (!send(s)) return
                i = end
                prev = if (cont) s else null
                if (!cont && !last) while (paused && !stopped) Thread.sleep(100)
            }
        }
    }

    private fun send(s: GestureDescription.StrokeDescription): Boolean {
        val latch = CountDownLatch(1); var ok = false
        ui.post {
            val g = GestureDescription.Builder().addStroke(s).build()
            val started = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(d: GestureDescription?) { latch.countDown() }
            }, null)
            if (!started) latch.countDown()
        }
        latch.await(30, TimeUnit.SECONDS)
        return ok
    }
}
